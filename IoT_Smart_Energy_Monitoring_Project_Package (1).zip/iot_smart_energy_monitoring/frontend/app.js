const API = '../backend/api.php';
let chart;

function fmt(value, digits=2) {
  const n = Number(value);
  return Number.isFinite(n) ? n.toFixed(digits) : '—';
}
async function loadDashboard() {
  const uid = document.querySelector('#deviceUid').value.trim();
  const status = document.querySelector('#connection');
  status.textContent = 'Loading…';
  try {
    const response = await fetch(`${API}?action=dashboard&device_uid=${encodeURIComponent(uid)}`);
    const payload = await response.json();
    if (!response.ok || !payload.ok) throw new Error(payload.error || 'Request failed');
    const rows = payload.readings || [];
    const latest = rows.at(-1);
    document.querySelector('#emptyState').hidden = rows.length > 0;
    if (latest) {
      document.querySelector('#voltage').textContent = fmt(latest.voltage_v);
      document.querySelector('#current').textContent = fmt(latest.current_a, 3);
      document.querySelector('#power').textContent = fmt(latest.power_w, 1);
      document.querySelector('#energy').textContent = fmt(latest.energy_kwh, 3);
    } else {
      ['voltage','current','power','energy'].forEach(id => document.querySelector(`#${id}`).textContent = '—');
    }
    const labels = rows.map(r => new Date(r.recorded_at.replace(' ', 'T')).toLocaleTimeString());
    const values = rows.map(r => Number(r.power_w));
    if (chart) chart.destroy();
    chart = new Chart(document.querySelector('#powerChart'), {
      type: 'line',
      data: { labels, datasets: [{ label: 'Power (W)', data: values, tension: .25, fill: false }] },
      options: { responsive: true, interaction: { intersect: false, mode: 'index' },
        scales: { y: { beginAtZero: true } } }
    });
    const body = document.querySelector('#alertsBody');
    body.replaceChildren();
    (payload.alerts || []).forEach(a => {
      const tr = document.createElement('tr');
      [a.triggered_at, a.device_name, a.message, a.status].forEach(value => {
        const td = document.createElement('td'); td.textContent = value ?? ''; tr.appendChild(td);
      });
      body.appendChild(tr);
    });
    if (!payload.alerts?.length) body.innerHTML = '<tr><td colspan="4">No alerts recorded.</td></tr>';
    status.textContent = `Updated ${new Date().toLocaleTimeString()}`;
  } catch (error) {
    status.textContent = `Unavailable: ${error.message}`;
  }
}
document.querySelector('#refreshBtn').addEventListener('click', loadDashboard);
document.querySelector('#printBtn').addEventListener('click', () => window.print());
loadDashboard();
setInterval(loadDashboard, 30000);
