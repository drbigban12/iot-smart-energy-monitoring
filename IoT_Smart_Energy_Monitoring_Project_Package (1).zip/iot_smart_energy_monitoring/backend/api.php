<?php
declare(strict_types=1);
require __DIR__ . '/config.php';

$action = $_GET['action'] ?? '';

if ($action === 'ingest' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $deviceUid = trim($_SERVER['HTTP_X_DEVICE_ID'] ?? '');
    $token = trim($_SERVER['HTTP_X_DEVICE_TOKEN'] ?? '');
    if ($deviceUid === '' || $token === '') jsonResponse(['ok'=>false,'error'=>'Missing device credentials'], 401);

    $stmt = $pdo->prepare("SELECT id, device_key_hash FROM devices WHERE device_uid=? AND status='active'");
    $stmt->execute([$deviceUid]);
    $device = $stmt->fetch();
    if (!$device || !hash_equals($device['device_key_hash'], hash('sha256', $token))) {
        jsonResponse(['ok'=>false,'error'=>'Invalid device credentials'], 401);
    }

    $data = requestJson();
    $allowed = ['voltage_v','current_a','power_w','energy_kwh','frequency_hz','power_factor'];
    foreach ($allowed as $field) {
        if (isset($data[$field]) && (!is_numeric($data[$field]) || !is_finite((float)$data[$field]))) {
            jsonResponse(['ok'=>false,'error'=>"Invalid numeric field: {$field}"], 422);
        }
    }
    foreach (['voltage_v','current_a','power_w','energy_kwh'] as $field) {
        if (!array_key_exists($field, $data)) jsonResponse(['ok'=>false,'error'=>"Missing field: {$field}"], 422);
    }
    if ((float)$data['voltage_v'] < 0 || (float)$data['current_a'] < 0 ||
        (float)$data['power_w'] < 0 || (float)$data['energy_kwh'] < 0) {
        jsonResponse(['ok'=>false,'error'=>'Negative readings are not accepted'], 422);
    }

    $recordedAt = isset($data['recorded_at']) ? date('Y-m-d H:i:s', strtotime((string)$data['recorded_at'])) : date('Y-m-d H:i:s');
    $stmt = $pdo->prepare("INSERT INTO energy_readings
      (device_id, recorded_at, voltage_v, current_a, power_w, energy_kwh, frequency_hz, power_factor)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->execute([
      $device['id'], $recordedAt, $data['voltage_v'], $data['current_a'],
      $data['power_w'], $data['energy_kwh'], $data['frequency_hz'] ?? null,
      $data['power_factor'] ?? null
    ]);
    $pdo->prepare("UPDATE devices SET last_seen=NOW() WHERE id=?")->execute([$device['id']]);

    // Evaluate active rules for this device. Cooldown avoids repeated alerts.
    $rules = $pdo->prepare("SELECT * FROM alert_rules WHERE enabled=1 AND (device_id=? OR device_id IS NULL)");
    $rules->execute([$device['id']]);
    foreach ($rules->fetchAll() as $rule) {
        $metric = $rule['metric'];
        if (!isset($data[$metric]) || (float)$data[$metric] <= (float)$rule['threshold_value']) continue;
        $recent = $pdo->prepare("SELECT id FROM alerts WHERE rule_id=? AND device_id=? AND triggered_at >= DATE_SUB(NOW(), INTERVAL ? MINUTE) LIMIT 1");
        $recent->execute([$rule['id'], $device['id'], (int)$rule['cooldown_minutes']]);
        if (!$recent->fetch()) {
            $message = sprintf('%s exceeded threshold: observed %s, limit %s',
                $rule['rule_name'], (string)$data[$metric], (string)$rule['threshold_value']);
            $ins = $pdo->prepare("INSERT INTO alerts
              (rule_id, device_id, metric, observed_value, threshold_value, message, triggered_at)
              VALUES (?, ?, ?, ?, ?, ?, NOW())");
            $ins->execute([$rule['id'], $device['id'], $metric, $data[$metric], $rule['threshold_value'], $message]);
        }
    }
    jsonResponse(['ok'=>true,'message'=>'Reading stored','reading_id'=>(int)$pdo->lastInsertId()], 201);
}

if ($action === 'dashboard') {
    // Demo endpoint: protect this endpoint with login/session checks before deployment.
    $deviceUid = trim($_GET['device_uid'] ?? '');
    $params = [];
    $where = '';
    if ($deviceUid !== '') { $where = 'WHERE d.device_uid=?'; $params[] = $deviceUid; }

    $stmt = $pdo->prepare("SELECT r.*, d.device_uid, d.device_name
      FROM energy_readings r JOIN devices d ON d.id=r.device_id {$where}
      ORDER BY r.recorded_at DESC LIMIT 100");
    $stmt->execute($params);
    $rows = array_reverse($stmt->fetchAll());

    $alertsStmt = $pdo->prepare("SELECT a.*, d.device_name FROM alerts a
      JOIN devices d ON d.id=a.device_id {$where}
      ORDER BY a.triggered_at DESC LIMIT 20");
    $alertsStmt->execute($params);
    jsonResponse(['ok'=>true,'readings'=>$rows,'alerts'=>$alertsStmt->fetchAll()]);
}

if ($action === 'report') {
    // Restrict by authenticated user/device ownership in a production deployment.
    $from = $_GET['from'] ?? date('Y-m-01');
    $to = $_GET['to'] ?? date('Y-m-d');
    if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $from) || !preg_match('/^\d{4}-\d{2}-\d{2}$/', $to)) {
        jsonResponse(['ok'=>false,'error'=>'Dates must use YYYY-MM-DD'], 422);
    }
    $stmt = $pdo->prepare("SELECT DATE(r.recorded_at) AS day,
      MIN(r.energy_kwh) AS first_energy_kwh, MAX(r.energy_kwh) AS last_energy_kwh,
      AVG(r.power_w) AS average_power_w, MAX(r.power_w) AS peak_power_w
      FROM energy_readings r WHERE r.recorded_at >= ? AND r.recorded_at < DATE_ADD(?, INTERVAL 1 DAY)
      GROUP BY DATE(r.recorded_at) ORDER BY day");
    $stmt->execute([$from, $to]);
    jsonResponse(['ok'=>true,'from'=>$from,'to'=>$to,'days'=>$stmt->fetchAll()]);
}

jsonResponse(['ok'=>false,'error'=>'Unknown action'], 404);
