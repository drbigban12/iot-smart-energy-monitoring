# System Test Plan

## Preconditions
- MySQL schema imported.
- PHP API configured and reachable.
- A test device record exists with SHA-256 hash of the device token.
- Dashboard served by a local web server.
- Reference energy meter available for physical accuracy tests.

## Test cases
| ID | Test | Expected result | Evidence to record |
|---|---|---|---|
| TC01 | Valid authenticated JSON reading | HTTP 201 and database row created | API response and row ID |
| TC02 | Missing device headers | HTTP 401 | Response body |
| TC03 | Invalid device token | HTTP 401 | Response body |
| TC04 | Invalid JSON | HTTP 400 | Response body |
| TC05 | Negative measurement | HTTP 422 | Response body |
| TC06 | Threshold exceeded | Alert inserted | Alert row and timestamp |
| TC07 | Repeated threshold event within cooldown | Duplicate alert suppressed | Alert count |
| TC08 | Dashboard request | Recent readings and alerts returned | JSON and browser screenshot |
| TC09 | Network outage | Device reports failure and resumes after reconnect | Serial log |
| TC10 | Compare against reference meter | Error calculated and documented | Paired measurements |
| TC11 | Mobile dashboard | Layout remains readable | Screenshot |
| TC12 | Unauthorized production request | Access denied | HTTP status and server log |

Do not claim a test passed until it has been run and evidence has been saved.
