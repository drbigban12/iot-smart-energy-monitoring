# IoT-Based Smart Energy Monitoring System

## Package contents
- `database/schema.sql` — MySQL schema.
- `backend/config.php` — PDO configuration and JSON helpers.
- `backend/api.php` — authenticated device ingestion, dashboard data, reports.
- `frontend/` — browser dashboard.
- `firmware/esp32_energy_monitor.ino` — ESP32/PZEM-004T v3 example.
- `tests/test_plan.md` — test plan.

## Local setup (XAMPP)
1. Copy the `iot_smart_energy_monitor` folder into `C:\xampp\htdocs\`.
2. Start Apache and MySQL in XAMPP.
3. Open phpMyAdmin and import `database/schema.sql`.
4. Configure database credentials in `backend/config.php` or environment variables.
5. Create an application user and device record. Generate the device token hash with PHP:
   `php -r "echo hash('sha256', 'YOUR_LONG_RANDOM_DEVICE_TOKEN'), PHP_EOL;"`
6. Store that hash in `devices.device_key_hash`; the firmware sends the original token.
7. Set the device UID in the firmware to match `devices.device_uid`.
8. Update Wi-Fi details and API URL in the firmware, then upload to the ESP32.
9. Open `http://localhost/iot_smart_energy_monitor/frontend/` in a browser.

## Important setup notes
- The dashboard endpoint is a prototype endpoint. Add login/session checks and ownership filtering before production.
- The report endpoint also requires user/device ownership filtering before production.
- For the initial demo, the database must contain a device owned by a valid user.
- PHP should be configured to display errors only in development, not production.
- Do not expose the development XAMPP server directly to the internet.
- Use HTTPS with certificate validation for the device API in production.
- The example firmware skips a reading when core meter values are invalid; it does not implement persistent offline buffering.
- Check the exact PZEM library version and pin assignments for your hardware.
- The meter's accumulated energy may reset depending on the hardware/library; document this in testing.
- This prototype is not a certified utility billing meter or a protective electrical device.

## Create a first user
Generate a password hash:
`php -r "echo password_hash('Use-A-Unique-Password', PASSWORD_DEFAULT), PHP_EOL;"`

Then insert the account in phpMyAdmin using the resulting hash:
`INSERT INTO users (full_name,email,password_hash,role) VALUES ('Administrator','admin@example.test','PASTE_HASH_HERE','admin');`

## Create a device
Use a unique UID and a long random token. Store only the SHA-256 token hash in `device_key_hash`. Associate the device with an existing `users.id`.
