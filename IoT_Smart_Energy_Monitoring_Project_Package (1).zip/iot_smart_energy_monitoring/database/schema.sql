CREATE DATABASE IF NOT EXISTS smart_energy_monitor
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE smart_energy_monitor;

CREATE TABLE IF NOT EXISTS users (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  full_name VARCHAR(120) NOT NULL,
  email VARCHAR(190) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  role ENUM('admin','user') NOT NULL DEFAULT 'user',
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS devices (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id BIGINT UNSIGNED NOT NULL,
  device_uid VARCHAR(100) NOT NULL UNIQUE,
  device_name VARCHAR(120) NOT NULL,
  device_key_hash CHAR(64) NOT NULL,
  status ENUM('active','inactive') NOT NULL DEFAULT 'active',
  last_seen DATETIME NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_devices_user FOREIGN KEY (user_id) REFERENCES users(id)
    ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS energy_readings (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  device_id BIGINT UNSIGNED NOT NULL,
  recorded_at DATETIME NOT NULL,
  voltage_v DECIMAL(9,3) NULL,
  current_a DECIMAL(10,4) NULL,
  power_w DECIMAL(11,3) NULL,
  energy_kwh DECIMAL(13,5) NULL,
  frequency_hz DECIMAL(7,3) NULL,
  power_factor DECIMAL(5,4) NULL,
  received_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_readings_device_time (device_id, recorded_at),
  CONSTRAINT fk_readings_device FOREIGN KEY (device_id) REFERENCES devices(id)
    ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS alert_rules (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id BIGINT UNSIGNED NOT NULL,
  device_id BIGINT UNSIGNED NULL,
  metric ENUM('power_w','energy_kwh','current_a') NOT NULL DEFAULT 'power_w',
  threshold_value DECIMAL(13,4) NOT NULL,
  rule_name VARCHAR(120) NOT NULL,
  enabled TINYINT(1) NOT NULL DEFAULT 1,
  cooldown_minutes INT UNSIGNED NOT NULL DEFAULT 15,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_rules_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  CONSTRAINT fk_rules_device FOREIGN KEY (device_id) REFERENCES devices(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS alerts (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  rule_id BIGINT UNSIGNED NULL,
  device_id BIGINT UNSIGNED NOT NULL,
  metric VARCHAR(30) NOT NULL,
  observed_value DECIMAL(13,4) NOT NULL,
  threshold_value DECIMAL(13,4) NOT NULL,
  message VARCHAR(255) NOT NULL,
  status ENUM('new','acknowledged','resolved') NOT NULL DEFAULT 'new',
  triggered_at DATETIME NOT NULL,
  acknowledged_at DATETIME NULL,
  INDEX idx_alerts_device_time (device_id, triggered_at),
  CONSTRAINT fk_alerts_rule FOREIGN KEY (rule_id) REFERENCES alert_rules(id) ON DELETE SET NULL,
  CONSTRAINT fk_alerts_device FOREIGN KEY (device_id) REFERENCES devices(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- Create an administrator password hash using PHP:
-- php -r "echo password_hash('ChangeThisPassword!', PASSWORD_DEFAULT), PHP_EOL;"
-- Then insert a user with that generated hash. Do not keep the example password.
