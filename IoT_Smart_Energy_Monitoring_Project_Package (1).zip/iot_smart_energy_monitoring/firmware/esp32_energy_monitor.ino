/*
  ESP32 + PZEM-004T v3 example firmware.
  Hardware: use a properly enclosed, isolated and correctly rated meter module.
  Never connect ESP32 pins directly to mains voltage.

  Install Arduino libraries:
    - PZEM-004T v3.0 library (mandulaj)
    - ArduinoJson
  Configure Wi-Fi, API URL, device UID and token for your environment.
  For production, use HTTPS with certificate validation; do not use insecure TLS.
*/
#include <WiFi.h>
#include <HTTPClient.h>
#include <ArduinoJson.h>
#include <PZEM004Tv30.h>

const char* WIFI_SSID = "CHANGE_ME";
const char* WIFI_PASSWORD = "CHANGE_ME";
const char* API_URL = "http://192.168.1.10/iot_smart_energy_monitor/backend/api.php?action=ingest";
const char* DEVICE_UID = "DEMO-ESP32-001";
const char* DEVICE_TOKEN = "REPLACE_WITH_RANDOM_DEVICE_SECRET";

HardwareSerial meterSerial(2);
PZEM004Tv30 pzem(meterSerial, 16, 17); // RX, TX: verify your module and board wiring
unsigned long lastSend = 0;
const unsigned long SEND_INTERVAL_MS = 15000;

void connectWiFi() {
  if (WiFi.status() == WL_CONNECTED) return;
  WiFi.mode(WIFI_STA);
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
  unsigned long started = millis();
  while (WiFi.status() != WL_CONNECTED && millis() - started < 20000) {
    delay(500);
  }
}

void setup() {
  Serial.begin(115200);
  meterSerial.begin(9600, SERIAL_8N1, 16, 17);
  connectWiFi();
}

void loop() {
  if (millis() - lastSend < SEND_INTERVAL_MS) {
    delay(100);
    return;
  }
  lastSend = millis();
  connectWiFi();
  if (WiFi.status() != WL_CONNECTED) {
    Serial.println("Wi-Fi unavailable; reading will be skipped in this basic example.");
    return;
  }

  float voltage = pzem.voltage();
  float current = pzem.current();
  float power = pzem.power();
  float energy = pzem.energy();
  float frequency = pzem.frequency();
  float pf = pzem.pf();

  // NaN indicates unavailable sensor data; never silently convert it to zero.
  if (isnan(voltage) || isnan(current) || isnan(power) || isnan(energy)) {
    Serial.println("Meter reading invalid; check meter connection.");
    return;
  }

  StaticJsonDocument<256> doc;
  doc["voltage_v"] = voltage;
  doc["current_a"] = current;
  doc["power_w"] = power;
  doc["energy_kwh"] = energy;
  if (!isnan(frequency)) doc["frequency_hz"] = frequency;
  if (!isnan(pf)) doc["power_factor"] = pf;
  doc["recorded_at"] = ""; // Server assigns receipt time when this is empty/invalid.

  String body;
  serializeJson(doc, body);
  HTTPClient http;
  http.begin(API_URL); // For production use HTTPS with CA certificate validation.
  http.addHeader("Content-Type", "application/json");
  http.addHeader("X-Device-ID", DEVICE_UID);
  http.addHeader("X-Device-Token", DEVICE_TOKEN);
  int code = http.POST(body);
  Serial.printf("POST status: %d\n", code);
  if (code > 0) Serial.println(http.getString());
  http.end();
}
