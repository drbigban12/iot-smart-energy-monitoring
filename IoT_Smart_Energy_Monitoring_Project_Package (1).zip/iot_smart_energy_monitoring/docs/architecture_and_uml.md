# Architecture and UML Diagrams

## Architecture
```mermaid
flowchart TD
  A[Metering module] --> B[ESP32 firmware]
  B --> C[HTTPS JSON API]
  C --> D[PHP validation and event processing]
  D --> E[(MySQL database)]
  E --> F[HTML CSS JavaScript dashboard]
  D --> G[Threshold alerts]
  E --> H[Reports and analytics]
```

## Sequence
```mermaid
sequenceDiagram
  participant M as Meter
  participant E as ESP32
  participant P as PHP API
  participant D as MySQL
  participant U as Dashboard
  M->>E: Measurement
  E->>P: Authenticated JSON
  P->>D: Validate and insert
  P->>D: Evaluate alert rules
  P-->>E: API response
  U->>P: Query dashboard
  P->>D: Read latest data
  D-->>P: Results
  P-->>U: JSON data
```

## ERD
```mermaid
erDiagram
  USERS ||--o{ DEVICES : manages
  DEVICES ||--o{ ENERGY_READINGS : records
  USERS ||--o{ ALERT_RULES : configures
  DEVICES o|--o{ ALERT_RULES : targets
  DEVICES ||--o{ ALERTS : produces
  ALERT_RULES o|--o{ ALERTS : triggers
```
